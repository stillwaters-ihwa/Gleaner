@echo off
rem Removes Gleaner's files and its YouTube helper. Node.js, yt-dlp and ffmpeg stay installed.
title Remove Gleaner
for %%K in ("HKCU\Software\Google\Chrome" "HKCU\Software\Microsoft\Edge" "HKCU\Software\Chromium" "HKCU\Software\BraveSoftware\Brave-Browser") do reg delete "%%~K\NativeMessagingHosts\com.gleaner.ytdlp" /f >nul 2>&1
rmdir /s /q "%LOCALAPPDATA%\Gleaner" 2>nul
echo Gleaner's files and YouTube helper were removed.
echo Last step: on your browser's extensions page, click Remove on Gleaner.
echo.
pause
