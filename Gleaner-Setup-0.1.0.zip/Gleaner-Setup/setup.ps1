# Gleaner setup: everything in one run, for this Windows user (no admin rights needed).
#  1. Puts Gleaner in %LOCALAPPDATA%\Gleaner\extension (one fixed place, so updates keep working)
#  2. Installs what the YouTube saver needs (Node.js, yt-dlp, ffmpeg) with winget, if missing
#  3. Sets up the YouTube helper for that folder
#  4. Opens the browser's extensions page with the folder copied, for the one step a browser
#     only lets a person do: "Load unpacked" (browsers don't allow programs to add extensions).
# Running it again updates Gleaner in place: then just click Reload on the extensions page.
param(
  [switch]$SkipVideoTools,
  [switch]$NoBrowser,
  [switch]$NoHelper,
  [string]$Target = (Join-Path $env:LOCALAPPDATA 'Gleaner\extension')
)
$ErrorActionPreference = 'Stop'
$here = Split-Path -Parent $MyInvocation.MyCommand.Path
$src = Join-Path $here 'extension'

function Say($text, $color = 'Gray') { Write-Host $text -ForegroundColor $color }
function Step($n, $text) { Write-Host "`n[$n/4] $text" -ForegroundColor Cyan }
function Has($cmd) { [bool](Get-Command $cmd -ErrorAction SilentlyContinue) }
function RefreshPath { $env:Path = [Environment]::GetEnvironmentVariable('Path', 'Machine') + ';' + [Environment]::GetEnvironmentVariable('Path', 'User') + ';' + (Join-Path $env:LOCALAPPDATA 'Microsoft\WinGet\Links') }

Say "`n  Gleaner setup" 'Red'
Say "  Everything Gleaner needs, in one run.`n"

if (-not (Test-Path (Join-Path $src 'manifest.json'))) { Say "The 'extension' folder is missing next to this file. Unzip the whole Gleaner-Setup folder first, then run Install Gleaner again." 'Red'; exit 1 }
$version = (Get-Content (Join-Path $src 'manifest.json') -Raw | ConvertFrom-Json).version

# 1. The extension, in one fixed place
Step 1 "Putting Gleaner $version in place"
$updating = Test-Path (Join-Path $Target 'manifest.json')
if ($updating) { Get-ChildItem $Target -Force | Remove-Item -Recurse -Force }
New-Item -ItemType Directory -Force $Target | Out-Null
Copy-Item (Join-Path $src '*') $Target -Recurse -Force
Say "  $Target"

# 2. Tools for saving YouTube videos (optional)
Step 2 'Tools for saving YouTube videos'
$wanted = @()
if (-not $SkipVideoTools) {
  RefreshPath
  if (-not (Has 'node')) { $wanted += @{ id = 'OpenJS.NodeJS.LTS'; name = 'Node.js' } }
  if (-not (Has 'yt-dlp')) { $wanted += @{ id = 'yt-dlp.yt-dlp'; name = 'yt-dlp' } }
  if (-not (Has 'ffmpeg')) { $wanted += @{ id = 'Gyan.FFmpeg'; name = 'ffmpeg' } }
}
if ($SkipVideoTools) { Say '  Skipped.' }
elseif (-not $wanted.Count) { Say '  Node.js, yt-dlp and ffmpeg are already installed.' }
elseif (-not (Has 'winget')) { Say "  winget isn't available, so these weren't installed: $(($wanted | ForEach-Object { $_.name }) -join ', '). Everything else in Gleaner works without them." 'Yellow' }
else {
  $answer = Read-Host "  Install $(($wanted | ForEach-Object { $_.name }) -join ', ') for the YouTube saver? [Y/n]"
  if ($answer -match '^(n|no)$') { Say '  Skipped. Run Install Gleaner again any time to add them.' }
  else {
    foreach ($w in $wanted) {
      Say "  Installing $($w.name)..."
      winget install --id $w.id -e --silent --accept-package-agreements --accept-source-agreements | Out-Null
      RefreshPath
    }
  }
}

# 3. The YouTube helper, allowed for this folder
Step 3 'Setting up the YouTube helper'
RefreshPath
if ($NoHelper) { Say '  Skipped.' }
elseif ((Has 'node') -and (Test-Path (Join-Path $Target 'helper\install.ps1'))) {
  & (Join-Path $Target 'helper\install.ps1') | Out-Null
  Say '  Done.'
} else { Say '  Skipped (Node.js is not installed). YouTube saving is off; everything else works.' }

# 4. The one step the browser keeps for a person
Step 4 'Adding Gleaner to your browser'
$edge = @("${env:ProgramFiles(x86)}\Microsoft\Edge\Application\msedge.exe", "$env:ProgramFiles\Microsoft\Edge\Application\msedge.exe") | Where-Object { Test-Path $_ } | Select-Object -First 1
$chrome = @("$env:ProgramFiles\Google\Chrome\Application\chrome.exe", "${env:ProgramFiles(x86)}\Google\Chrome\Application\chrome.exe", "$env:LOCALAPPDATA\Google\Chrome\Application\chrome.exe") | Where-Object { Test-Path $_ } | Select-Object -First 1
$browsers = @()
if ($edge) { $browsers += @{ name = 'Edge'; exe = $edge; page = 'edge://extensions' } }
if ($chrome) { $browsers += @{ name = 'Chrome'; exe = $chrome; page = 'chrome://extensions' } }
if ($browsers.Count -gt 1 -and -not $NoBrowser) {
  $pick = Read-Host '  Add Gleaner to Edge, Chrome, or both? [E/c/b]'
  if ($pick -match '^c') { $browsers = @($browsers | Where-Object { $_.name -eq 'Chrome' }) }
  elseif ($pick -notmatch '^b') { $browsers = @($browsers | Where-Object { $_.name -eq 'Edge' }) }
}
if (-not $NoBrowser) { Set-Clipboard -Value $Target }

if ($updating) {
  Say "  Gleaner was updated. On the extensions page, click Reload on Gleaner." 'Green'
} else {
  Say '  The extensions page opens now. The folder Gleaner lives in is copied, ready to paste:' 'Green'
  Say '    1. Turn on Developer mode.'
  Say '    2. Click Load unpacked.'
  Say '    3. In the folder window, click the address bar at the top, press Ctrl+V, then Enter.'
  Say '    4. Click Select Folder. Gleaner appears in the list.'
  Say '    5. Pin it: click the puzzle piece in the toolbar, then the pin next to Gleaner.'
}
if (-not $NoBrowser) { foreach ($b in $browsers) { Start-Process $b.exe $b.page } }
if (-not $browsers.Count) { Say '  No Edge or Chrome found. Open your browser''s extensions page and load this folder:' 'Yellow'; Say "  $Target" }

Say "`n  Gleaner is ready. Run Install Gleaner again whenever you get a newer version.`n" 'Green'
